package Model;

public class ApiToken {
    private String API_TOKEN;

    public ApiToken(String API_TOKEN) {
        this.API_TOKEN = API_TOKEN;
    }

    public String getAPI_TOKEN() {
        return API_TOKEN;
    }

    public void setAPI_TOKEN(String API_TOKEN) {
        this.API_TOKEN = API_TOKEN;
    }
}
